import os
import cv2
import time
import threading
import numpy as np
import random
import sqlite3
import json
from datetime import datetime
from collections import deque
from queue import Queue
from flask import Flask, Response, jsonify, send_from_directory, request
from flask_cors import CORS
from ultralytics import YOLO
from pedestrian_engine import PedestrianEngine
from mailer import send_violation_email
from speed_engine import SpeedEngine

app = Flask(__name__)
CORS(app)

VIOLATIONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ihlal_kayitlari")
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "violations.db")
if not os.path.exists(VIOLATIONS_DIR):
    os.makedirs(VIOLATIONS_DIR)

# SQLite Setup
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS violations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER,
            cam_name TEXT,
            type TEXT,
            timestamp DATETIME,
            image_path TEXT,
            video_path TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# SSE (Server-Sent Events) Clients Queue List
sse_clients = []

cameras = {}

class CameraEngine:
    def __init__(self, cam_id, name, source, model=None):
        self.cam_id = cam_id
        self.name = name
        self.source = source
        if model:
            self.model = model
        else:
            print(f"[{self.name}] YOLOv11n model yukleniyor (Performans Modu)...")
            self.model = YOLO("yolo11n.pt")
            
        self.cap = cv2.VideoCapture(source)
        # Videoyu 2:50'den (170. saniye) başlat
        self.cap.set(cv2.CAP_PROP_POS_MSEC, 170 * 1000)
        self.current_frame = None
        
        # Tarayıcılar için H264 (avc1) deneyelim
        self.fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        
        # Kamera FPS değerini al, okuyamazsa varsayılan 25 kabul et
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        if not self.fps or self.fps < 10:
            self.fps = 25.0
            
        self.frame_buffer = deque(maxlen=int(self.fps * 4)) # Geriye dönük 4 saniyelik tampon
        self.recording_frames_left = 0
        self.current_writer = None
        
        self.violation_count = 0
        self.alert_timer = 0
        self.prev_positions = {}
        self.start_points = {}
        self.violation_scores = {}
        self.downward_streak = {}
        self.track_age = {}
        self.violators = set()
        self.last_alert_time = 0
        self.violation_cooldown = 0
        self.pos_history = {}
        self.post_reset_grace = {}
        self.vehicle_logged = set()
        
        self.on_violation = None
        self.frame_buffer = deque(maxlen=int(self.fps * 4))
        self.active_writers = []
        self.fourcc = cv2.VideoWriter_fourcc(*'mp4v')

    def log_violation(self, vehicle_id, frame, box=None):
        current_time = time.time()
        if (current_time - self.last_alert_time) < 15:
            return

        timestamp = datetime.now().strftime("%H%M%S_%f")
        rand_suffix = random.randint(1000, 9999)
        img_name = f"ters_cam{self.cam_id}_ID{vehicle_id}_{timestamp}_{rand_suffix}.jpg"
        vid_name = f"ters_cam{self.cam_id}_ID{vehicle_id}_{timestamp}_{rand_suffix}.mp4"
        
        img_path = os.path.join(VIOLATIONS_DIR, img_name)
        cv2.imwrite(img_path, frame)
        
        crop_name = f"crop_{img_name}"
        crop_path = os.path.join(VIOLATIONS_DIR, crop_name)
        if box is not None:
            try:
                y1, y2 = max(0, int(box[1]-80)), min(frame.shape[0], int(box[3]+80))
                x1, x2 = max(0, int(box[0]-80)), min(frame.shape[1], int(box[2]+80))
                crop_img = frame[y1:y2, x1:x2]
                cv2.imwrite(crop_path, crop_img)
            except: cv2.imwrite(crop_path, frame)
        else:
            cv2.imwrite(crop_path, frame)
            
        vid_path = os.path.join(VIOLATIONS_DIR, vid_name)
        h, w = 450, 800
        writer = cv2.VideoWriter(vid_path, self.fourcc, self.fps, (w, h))
        if writer.isOpened():
            for buf_frame in self.frame_buffer:
                writer.write(buf_frame)
            self.active_writers.append({'writer': writer, 'frames_left': int(self.fps * 5)})
        
        timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO violations (vehicle_id, cam_name, type, timestamp, image_path, video_path)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (int(vehicle_id), self.name, "Ters Yön İhlali", timestamp_str, img_name, vid_name))
        conn.commit()
        last_id = cursor.lastrowid
        conn.close()

        if self.on_violation:
            self.on_violation({
                "id": int(vehicle_id),
                "db_id": last_id,
                "cam_name": self.name,
                "type": "Ters Yön İhlali",
                "time": timestamp_str,
                "img": img_name,
                "crop": crop_name,
                "video": vid_name
            })

        self.last_alert_time = current_time

    def process(self):
        frame_counter = 0
        results = None
        
        while self.cap.isOpened():
            success, frame = self.cap.read()
            if not success: break
            
            h, w, _ = frame.shape
            line_y     = int(h * 0.72)
            top_line_y = int(h * 0.40)
            corridor_x_min = int(w * 0.12)
            corridor_x_max = int(w * 0.88)

            frame_counter += 1
            if frame_counter % 4 == 0:
                results = self.model.track(frame, persist=True, classes=[2, 5, 7], imgsz=320, verbose=False)

            if results and results[0].boxes.id is not None:
                boxes = results[0].boxes.xyxy.cpu().numpy().astype(int)
                ids = results[0].boxes.id.cpu().numpy().astype(int)
                confs = results[0].boxes.conf.cpu().numpy()

                for box, id, conf in zip(boxes, ids, confs):
                    cx = int((box[0] + box[2]) / 2)
                    cy = int((box[1] + box[3]) / 2)
                    bbox_w, bbox_h = box[2]-box[0], box[3]-box[1]
                    bbox_area = bbox_w * bbox_h

                    if conf < 0.60: continue
                    min_area = 3000 if cy < top_line_y else 8000
                    if bbox_area < min_area: continue
                    aspect = bbox_w / (bbox_h + 1e-5)
                    if aspect < 0.45 or aspect > 3.0: continue

                    self.track_age[id] = self.track_age.get(id, 0) + 1
                    if self.track_age[id] < 8:
                        self.prev_positions[id] = cy
                        continue

                    if id not in self.pos_history:
                        self.pos_history[id] = deque(maxlen=20)
                    self.pos_history[id].append(cy)
                    if cy < top_line_y and len(self.pos_history[id]) >= 15:
                        pos_range = max(self.pos_history[id]) - min(self.pos_history[id])
                        if pos_range < 10:
                            self.prev_positions[id] = cy
                            continue

                    if id not in self.start_points:
                        self.start_points[id] = (cx, cy)
                        self.violation_scores[id] = 0
                        self.downward_streak[id] = 0

                    if id in self.prev_positions:
                        dy = cy - self.prev_positions[id]
                        prev_cy = self.prev_positions[id]
                        start_x, start_y = self.start_points[id]
                        total_dx = abs(cx - start_x)
                        total_dy = cy - start_y

                        if dy > 1: self.downward_streak[id] = self.downward_streak.get(id, 0) + 1
                        elif dy < -2: self.downward_streak[id] = 0

                        if self.post_reset_grace.get(id, 0) > 0: self.post_reset_grace[id] -= 1
                        if self.downward_streak.get(id, 0) >= 4:
                            self.violation_scores[id] = 0
                            self.start_points[id] = (cx, cy)
                            self.post_reset_grace[id] = 15 

                        grace = self.post_reset_grace.get(id, 0)
                        if self.downward_streak.get(id, 0) >= 3 or total_dy >= 0 or grace > 0:
                            self.prev_positions[id] = cy
                            continue

                        is_vertical_dominant = (abs(total_dy) > total_dx * 1.5)

                        if prev_cy >= top_line_y and cy < top_line_y:
                            age = self.track_age.get(id, 0)
                            if is_vertical_dominant and age >= 15 and dy < -2 and id not in self.vehicle_logged:
                                self.vehicle_logged.add(id)
                                self.violators.add(id)
                                self.log_violation(id, frame, box)
                        elif top_line_y <= cy < line_y and dy < -1:
                            self.violation_scores[id] += abs(dy)
                            age = self.track_age.get(id, 0)
                            if (self.violation_scores[id] > 30 and total_dy <= -40 and is_vertical_dominant and age >= 15):
                                if id not in self.vehicle_logged:
                                    self.vehicle_logged.add(id)
                                    self.violators.add(id)
                                    self.log_violation(id, frame, box)
                        elif cy < top_line_y and dy < -1:
                            age = self.track_age.get(id, 0)
                            if age >= 20:
                                self.violation_scores[id] += abs(dy)
                                if (self.violation_scores[id] > 20 and total_dy <= -25 and is_vertical_dominant):
                                    if id not in self.vehicle_logged:
                                        self.vehicle_logged.add(id)
                                        self.violators.add(id)
                                        self.log_violation(id, frame, box)

                    self.prev_positions[id] = cy

                    is_bad = id in self.violators
                    color  = (0, 0, 255) if is_bad else (0, 255, 0)
                    cv2.rectangle(frame, (box[0], box[1]), (box[2], box[3]), color, 12 if is_bad else 2)
                    cv2.putText(frame, f"ID:{id} ({conf:.2f})", (box[0], box[1]-10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)

            if self.violation_cooldown > 0:
                self.violation_cooldown -= 1

            # Koridor dikey sınırlarını çiz
            cv2.line(frame, (0, line_y), (w, line_y), (0, 255, 255), 2)
            cv2.putText(frame, "DETECTION ZONE", (10, line_y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
            cv2.line(frame, (0, top_line_y), (w, top_line_y), (0, 255, 0), 2)
            cv2.putText(frame, "TOP GATE", (10, top_line_y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

            # Koridor X sınırlarını çiz (sol/sağ dışlanan bölgeler)
            cv2.line(frame, (corridor_x_min, 0), (corridor_x_min, h), (100, 100, 255), 1)
            cv2.line(frame, (corridor_x_max, 0), (corridor_x_max, h), (100, 100, 255), 1)
            if self.alert_timer > 0:
                cv2.rectangle(frame, (0,0), (w,h), (0,0,255), 15)
                self.alert_timer -= 1

            preview = cv2.resize(frame, (800, 450))
            self.frame_buffer.append(preview) # Geçmiş için tampona kaydet
            
            _, buffer = cv2.imencode('.jpg', preview)
            self.current_frame = buffer.tobytes()
            
            # Eğer kayıt devam ediyorsa güncel kareyi de yaz
            # Aktif video kayıtlarını güncelle
            if hasattr(self, 'active_writers'):
                for rec in self.active_writers[:]:
                    rec['writer'].write(preview)
                    rec['frames_left'] -= 1
                    if rec['frames_left'] <= 0:
                        rec['writer'].release()
                        self.active_writers.remove(rec)

            # cv2.imshow("Viraj Korumali Analiz", preview)
            # if cv2.waitKey(1) & 0xFF == ord('q'): break

        self.cap.release()
        if self.current_writer is not None:
            self.current_writer.release()
        cv2.destroyAllWindows()
        
    def get_frame(self):
        return self.current_frame

# Başlat
engine = CameraEngine(1, "Ana Koridor", "video/192.168.12.5_ch49_20260422112301_20260422113058_ters_yön.avi")
cameras[1] = engine

engine2 = PedestrianEngine(2, "Güvensiz Bölge", "video/192.168.12.5_ch45_20260422112303_20260422113058_güvensiz.avi", model=YOLO("yolo11n.pt"))
engine3 = SpeedEngine(3, "Hız Koridoru", "video/192.168.12.5_ch50_20260422112304_20260422113058_hız.avi", model=YOLO("yolo11n.pt"))
# Hız videosunu 2:30'dan başlat
engine3.cap.set(cv2.CAP_PROP_POS_MSEC, 150 * 1000)

cameras[1] = engine
cameras[2] = engine2
cameras[3] = engine3

def notify_pedestrian(data):
    event_data = {
        "id": data["id"], 
        "cam_name": data["camera_name"], 
        "type": data["type"], 
        "time": data["timestamp"], 
        "img": os.path.basename(data["image_path"]), 
        "video": os.path.basename(data.get("video_path", ""))
    }
    msg = json.dumps(event_data)
    for q in sse_clients:
        q.put(msg)
        
    # Asenkron E-Posta Gönderimi (Video Dahil)
    vid_path = data.get("video_path")
    threading.Thread(
        target=send_violation_email,
        args=(event_data["cam_name"], event_data["type"], event_data["id"], event_data["time"], data["image_path"], vid_path),
        daemon=True
    ).start()

engine2.on_violation = notify_pedestrian

def notify_clients(data):
    msg = json.dumps(data)
    for q in sse_clients:
        q.put(msg)
        
    # Asenkron E-Posta Gönderimi (Video Dahil)
    img_full_path = os.path.join(VIOLATIONS_DIR, data["img"])
    vid_full_path = os.path.join(VIOLATIONS_DIR, data["video"]) if data.get("video") else None
    threading.Thread(
        target=send_violation_email,
        args=(data["cam_name"], data["type"], data["id"], data["time"], img_full_path, vid_full_path),
        daemon=True
    ).start()

engine.on_violation = notify_clients
engine3.on_violation = notify_clients

@app.route('/screenshots/<path:filename>')
def get_screenshot(filename):
    return send_from_directory(VIOLATIONS_DIR, filename)

@app.route('/videos/<path:filename>')
def get_video(filename):
    return send_from_directory(VIOLATIONS_DIR, filename)

# ── MOTORLARIN BAŞLATILMASI (YOLOv11n - Performans Modu) ──
print("[Sistem] İşlemci uyumlu Nano modeller yükleniyor...", flush=True)

engine1 = CameraEngine(1, "Ana Koridor", "video/192.168.12.5_ch49_20260422112301_20260422113058_ters_yön.avi", model=YOLO("yolo11n.pt"))
engine2 = PedestrianEngine(2, "Yaya Geçidi", "video/192.168.12.5_ch45_20260422112303_20260422113058_güvensiz.avi", model=YOLO("yolo11n.pt"))
engine3 = SpeedEngine(3, "Hız Koridoru", "video/192.168.12.5_ch50_20260422112304_20260422113058_hız.avi", model=YOLO("yolo11n.pt"))

def notify_pedestrian(data):
    msg = json.dumps(data)
    for q in sse_clients:
        q.put(msg)
    img_path = data.get("image_path")
    if img_path:
        threading.Thread(
            target=send_violation_email,
            args=(data["camera_name"], data["type"], data["vehicle_id"], data["timestamp"], img_path),
            daemon=True
        ).start()

def notify_clients(data):
    msg = json.dumps(data)
    for q in sse_clients:
        q.put(msg)
    img_name = data.get("img")
    if img_name:
        img_full_path = os.path.join(VIOLATIONS_DIR, img_name)
        threading.Thread(
            target=send_violation_email,
            args=(data["cam_name"], data["type"], data["id"], data["time"], img_full_path),
            daemon=True
        ).start()

engine1.on_violation = notify_clients
engine2.on_violation = notify_pedestrian
engine3.on_violation = notify_clients

@app.route('/vehicle_stream')
def vehicle_stream_alias():
    return video_feed(1)

@app.route('/pedestrian_stream')
def pedestrian_stream_alias():
    return video_feed(2)

@app.route('/speed_stream')
def speed_stream_alias():
    return video_feed(3)

@app.route('/stream')
def stream_alias():
    return video_feed(1)

@app.route('/video_feed/<int:cam_id>')
def video_feed(cam_id):
    def generate():
        engine = None
        if cam_id == 1: engine = engine1
        elif cam_id == 2: engine = engine2
        elif cam_id == 3: engine = engine3
        while True:
            if engine:
                frame = engine.get_frame()
                if frame:
                    yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            time.sleep(0.04)
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/events')
def events():
    def event_stream():
        q = queue.Queue()
        sse_clients.append(q)
        try:
            while True:
                yield f"data: {q.get()}\n\n"
        except GeneratorExit:
            sse_clients.remove(q)
    return Response(event_stream(), mimetype="text/event-stream")

@app.route('/stats')
def stats():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM violations ORDER BY timestamp DESC')
    rows = cursor.fetchall()
    history = []
    for r in rows:
        history.append({
            "id": r['id'],
            "vehicle_id": r['vehicle_id'],
            "cam_name": r['cam_name'],
            "type": r['type'],
            "time": r['timestamp'],
            "img": r['image_path'],
            "video": r['video_path']
        })
    cursor.execute('SELECT COUNT(*) FROM violations')
    total = cursor.fetchone()[0]
    conn.close()
    return jsonify({"total": total, "history": history})

@app.route('/delete_violation/<int:violation_id>', methods=['DELETE'])
def delete_violation(violation_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT image_path, video_path FROM violations WHERE id = ?', (violation_id,))
    row = cursor.fetchone()
    if row:
        img_path, vid_path = row
        for f in [img_path, vid_path, f"crop_{img_path}"]:
            if f:
                p = os.path.join(VIOLATIONS_DIR, os.path.basename(f))
                if os.path.exists(p):
                    try: os.remove(p)
                    except: pass
        cursor.execute('DELETE FROM violations WHERE id = ?', (violation_id,))
        conn.commit()
    conn.close()
    return jsonify({"success": True})



if __name__ == '__main__':
    def run_engine(e):
        e.process()

    threading.Thread(target=run_engine, args=(engine1,), daemon=True).start()
    threading.Thread(target=run_engine, args=(engine2,), daemon=True).start()
    threading.Thread(target=run_engine, args=(engine3,), daemon=True).start()
    
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
